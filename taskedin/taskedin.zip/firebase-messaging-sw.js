importScripts("https://www.gstatic.com/firebasejs/9.14.0/firebase-app-compat.js");
importScripts("https://www.gstatic.com/firebasejs/9.14.0/firebase-messaging-compat.js");
firebase.initializeApp({
  // apiKey: "AIzaSyCe2ZoKwHwnu5XzciD-k5T_pIaBLj8HAAg",
  // authDomain: "taskedin-qc.firebaseapp.com",
  // databaseURL: "https://taskedin-qc.firebaseio.com",
  // projectId: "taskedin-qc",
  // storageBucket: "taskedin-qc.appspot.com",
  // messagingSenderId: "293646904736",
  // appId: "1:293646904736:web:7b44ef16a260500dd388c5",
  // measurementId: "G-F2VC1BVCBW",
  apiKey: "AIzaSyAa8_AbhPRfRRgNj2_Bj0CfebaAttNaVZU",
  authDomain: "taskedin-13b36.firebaseapp.com",
  databaseURL: "https://taskedin-13b36.firebaseio.com",
  projectId: "taskedin-13b36",
  storageBucket: "taskedin-13b36.appspot.com",
  messagingSenderId: "342226115526",
  appId: "1:342226115526:web:3cd7422416be77ef1870c7",
  measurementId: "G-220JZD902D",
});
const messaging = firebase.messaging();
